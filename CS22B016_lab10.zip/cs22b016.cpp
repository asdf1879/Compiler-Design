#include <bits/stdc++.h>

using namespace std;


void LinearScan(map<string,pair<int,int>> &var_range,int K,int max_time){
    set<int> free_regs;
    for(int i=0;i<K;i++){
        free_regs.insert(i);
    }
    int time=1;
    map<string,int> register_mapping;
    set<string> cur_live_vars;
    for(;time<max_time;time++){
        for(auto i: var_range){
            if(i.second.second==time){
                int to_free=register_mapping[i.first];
                if(to_free==-1){
                    ;
                }
                else{
                    free_regs.insert(to_free);
                    register_mapping.erase(i.first);
                }
                cur_live_vars.erase(i.first);
            }
        }

        for(auto i: var_range){
            if(i.second.first==time){
                int to_allocate;
                if(!free_regs.empty())
                {
                    to_allocate=*free_regs.begin();
                    free_regs.erase(to_allocate);
                }
                else
                to_allocate=-1;  //-1 for memory
                register_mapping[i.first]=to_allocate;
                cur_live_vars.insert(i.first);
            }
        }

        for(auto i: cur_live_vars){
            if(register_mapping[i]==-1){
                cout<<i<<" "<<time<<" "<<"memory\n";
            }
            else{
                cout<<i<<" "<<time<<" "<<register_mapping[i]+1<<endl;  // used 0 to k-1
            }
        }

    }

}


map<string,set<string>> ConstructGraph(map<string,pair<int,int>> &var_range,int max_time){
    set<string> cur_live;
    map<string,set<string>> adjList;

    for(auto i: var_range){
        for(auto j: var_range){
            if(i.first==j.first){
                continue;
            }
            // check if range intersects
            if(i.second.first<=j.second.first && i.second.second>j.second.first){
                adjList[i.first].insert(j.first);
                adjList[j.first].insert(i.first);
            }
            else if(j.second.first<=i.second.first && j.second.second>i.second.first){
                adjList[i.first].insert(j.first);
                adjList[j.first].insert(i.first);
            }
        }
    }

    return adjList;
}

struct comp{
    bool operator()(const pair<int,string>&p1, const pair<int,string>&p2) const {
        if(p1.first==p2.first){
            return p1.second>p2.second;
        }
        
            return p1.first<p2.first;
        
    }
};

void GraphColoring(map<string,pair<int,int>> &var_range,int K,int max_time){
    map<string,set<string>> adjList= ConstructGraph(var_range,max_time);
    map<string,int> degree;
    set<pair<int,string>,comp> sorted_degrees;
    set<string> setofall;  //uncolored
    for(auto i: adjList){
        degree[i.first]=i.second.size();
        // setofall.insert(i.first);
        sorted_degrees.insert({i.second.size(),i.first});
    }

    for(auto i: var_range){
        setofall.insert(i.first);
    }


    map<string,int> colormap;
    int color_counter=0;
    vector<pair<int,string>> vect;
    for(auto i=sorted_degrees.rbegin();i!=sorted_degrees.rend();i++){
        vect.push_back(*i);
        // cout<<i->second<<endl;

    }
    // cout<<vect.size()<<endl;
    for(int i=0;i<vect.size();i++){
        string var_name=vect[i].second;
        
        if(colormap.find(var_name)!=colormap.end()){
            
            continue;
        }
        colormap[var_name]=++color_counter;
        
        for(int j=i+1;j<vect.size();j++){
            
            string vna=vect[j].second;  
            if(colormap.find(vna)!=colormap.end()){

                continue;
            }
            
            bool f=true;
            for(auto k:adjList[vna]){
                if(colormap.find(k)!=colormap.end()){
                    if(colormap[k]==color_counter){
                        f=false;
                        continue;
                    }
                    
                }
            }
            if(f){
                colormap[vna]=color_counter;
            }
            
        }

    }

    set<string> cur_live;

    for(int time=1;time<max_time;time++){
        for(auto i: var_range){
            if(i.second.second==time){
                cur_live.erase(i.first);
            }
        }

        for(auto i: var_range){
            if(i.second.first==time){
                cur_live.insert(i.first);
            }
        }
        
        for(auto i: cur_live){
            string s;
            if(colormap[i]>K){
                s="memory";
            }
            else{
                s=to_string(colormap[i]);
            }
            cout<<i<<" "<<time<<" "<<s<<endl;
        }
        
    }


}  

int main(){
    int K;
    int N;
    cin>>K;
    cin>>N;
    map<string,pair<int,int>> var_range;
    int max_time=0;
    for(int i=0;i<N;i++){
        string s;
        int st;
        int et;
        cin>>s>>st>>et;
        max_time=max(max_time,et);
        var_range[s]={st,et};

    }
    // cout<<"hi";
    // cout<<max_time<<endl;
    cout<<"Linear Scan:\n";
    LinearScan(var_range,K,max_time);
    
    cout<<"Graph Coloring:\n";

    GraphColoring(var_range,K,max_time);

    

}